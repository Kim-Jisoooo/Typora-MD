<?php
$con=mysqli_connect("localhost","root","123456","test");

if (mysqli_connect_errno())
{
	echo "连接失败: " . mysqli_connect_error();
}
$id = intval($_GET['id']);
$result = mysqli_query($con,"select * from users where `id`=".$id);

$row = mysqli_fetch_array($result);

$username = $row['username'];
//  $username = ?  会危险 select * from users where `username`='   abc'  or  1=1 limit 1,1%23   '
$result2 = mysqli_query($con,"select * from users where `username`='".$username."'"); // 这个用户名在其他查询中存在注入漏洞

if($row2 = mysqli_fetch_array($result2)){
	// echo $row2['username'] . " : " . $row2['money'];
	echo $row2['username'] ;
}else{
	echo mysqli_error($con);
}
?>
