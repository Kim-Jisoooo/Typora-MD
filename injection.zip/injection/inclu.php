<?php


$filename = $_GET['filename'];
include $filename;    // 或include_once, require, require_once

echo "欢迎来到PHP的世界.";


?>
